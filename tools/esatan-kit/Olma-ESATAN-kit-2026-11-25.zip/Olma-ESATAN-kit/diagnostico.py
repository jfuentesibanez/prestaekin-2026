#!/usr/bin/env python3
"""Diagnóstico local sin ejecutar ESATAN, leer modelos ni leer licencias.

Python 3.8+ estándar. Los informes no incluyen rutas absolutas, nombres de
usuario, servidores, variables de licencia ni contenido de los archivos.
"""
import argparse
import json
import os
import platform
import re
import shutil
import sys
from pathlib import Path

SKIP = {'models', 'model', 'user', 'projects', 'project', 'licences', 'licenses',
        'license', 'licence', 'node_modules', '.git', '__pycache__'}


def candidates(manual):
    roots = [Path(p).expanduser() for p in manual]
    for name in ('C:/ESATAN-TMS', 'C:/ESATAN_TMS', '/opt/ESATAN-TMS', '/usr/local/ESATAN-TMS'):
        root = Path(name)
        if root.is_dir():
            roots.append(root)
    # PATH puede indicar la instalación. ESATAN_TMS_HOME no: contiene preferencias/modelos.
    for value in os.environ.get('PATH', '').split(os.pathsep):
        p = Path(value)
        if 'esatan' in value.lower() and p.is_dir():
            for parent in (p,) + tuple(p.parents):
                if 'esatan' in parent.name.lower():
                    roots.append(parent)
                    break
    unique = []
    for p in roots:
        if p.is_symlink():
            continue
        try:
            resolved = p.resolve()
        except OSError:
            continue
        if resolved not in unique:
            unique.append(resolved)
    return unique


def inspect_install(root, number, max_items=3000, max_depth=5):
    info = {'identificador': 'instalacion_%d' % number, 'directorio_existe': root.is_dir(),
            'versiones_en_nombre': [], 'carpeta_api': False, 'ejemplos_api': False,
            'ejemplo_tmd_maker': False, 'documentacion_api': False,
            'ejecutable_esatan': False, 'radiative_bin': False,
            'thermal_bin': False, 'exploracion_limitada': False}
    if not root.is_dir():
        return info
    years = set(re.findall(r'20\d{2}', root.name))
    count = 0
    for current, dirs, files in os.walk(str(root), followlinks=False):
        rel = Path(current).relative_to(root)
        count += len(dirs) + len(files)
        if count > max_items:
            info['exploracion_limitada'] = True
            break
        if len(rel.parts) >= max_depth:
            if dirs:
                info['exploracion_limitada'] = True
            dirs[:] = []
        else:
            dirs[:] = [d for d in dirs if d.lower() not in SKIP and
                       not d.startswith('.') and not (Path(current) / d).is_symlink()]
        parts = [x.lower() for x in rel.parts]
        for d in dirs:
            if re.fullmatch(r'20\d{2}(?:[ _-]?sp\d+)?', d, flags=re.I):
                years.update(re.findall(r'20\d{2}', d))
        if 'api' in parts or any(d.lower() == 'api' for d in dirs):
            info['carpeta_api'] = True
        if 'api' in parts and ('examples' in parts or any(d.lower() == 'examples' for d in dirs)):
            info['ejemplos_api'] = True
        if 'radiative' in parts and parts[-1:] == ['bin']:
            info['radiative_bin'] = True
        if 'thermal' in parts and parts[-1:] == ['bin']:
            info['thermal_bin'] = True
        for f in files:
            low = f.lower()
            if low.endswith(('.lic', '.key')) or 'licen' in low:
                continue
            if low in ('esatan-tms', 'esatan-tms.exe', 'esatan-tms.bat', 'esatan.exe'):
                info['ejecutable_esatan'] = True
            if 'tmd_maker' in low and 'api' in parts:
                info['ejemplo_tmd_maker'] = True
            if 'api' in low and low.endswith(('.pdf', '.html', '.htm', '.chm')):
                info['documentacion_api'] = True
    info['versiones_en_nombre'] = sorted(years)
    return info


def report(manual):
    installs = [inspect_install(p, i + 1) for i, p in enumerate(candidates(manual))]
    v = sys.version_info
    return {
        'kit': 'Olma ESATAN 2026-11-25',
        'nivel': 'INVENTARIO_LOCAL_NO_CONEXION',
        'sistema': platform.system(),
        'python_del_diagnostico': '%s.%s.%s' % (v.major, v.minor, v.micro),
        'python_compatible_api_2026': v.major == 3 and v.minor == 12,
        'python_recomendado_api_2026': v.major == 3 and v.minor == 12 and v.micro >= 4,
        'esatan_tms_home_configurado': bool(os.environ.get('ESATAN_TMS_HOME')),
        'comando_en_path': any(shutil.which(n) for n in ('esatan-tms', 'esatan-tms.exe', 'esatan-tms.bat')),
        'instalaciones': installs,
        'advertencia': 'Versiones inferidas por nombres; confirmar en Ayuda/Acerca de. No se ha ejecutado ESATAN ni probado API, licencia o solver.',
        'siguiente_paso': 'Abrir Workbench y su API Guide. Usar prueba_workbench.py en el contexto de plugins documentado para esa instalación.'
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install', action='append', default=[], help='Ruta de instalación, NO carpeta de modelos. Repetible.')
    parser.add_argument('--output', type=Path, help='Guardar informe JSON (única escritura del diagnóstico).')
    parser.add_argument('--dry-run', action='store_true', help='Explica el diagnóstico sin explorar ni escribir.')
    args = parser.parse_args(argv)
    if args.dry_run:
        print('Se comprobarán nombres de carpetas/ejecutables de instalación, PATH y Python. No se ejecutará ESATAN, no se leerán modelos/licencias y no se harán peticiones de red. --output guardaría un informe sin rutas absolutas.')
        return 0
    data = report(args.install)
    content = json.dumps(data, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content + '\n', encoding='utf-8')
    print(content)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
