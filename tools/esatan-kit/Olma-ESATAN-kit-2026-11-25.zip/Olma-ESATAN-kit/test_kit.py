import contextlib
import io
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch
import diagnostico
import prueba_workbench
import postproceso_csv


class KitTest(unittest.TestCase):
    def test_inventory_detects_structure_without_leaking_path(self):
        with tempfile.TemporaryDirectory(prefix='privado-') as tmp:
            base=Path(tmp)/'2026';(base/'API'/'examples').mkdir(parents=True)
            (base/'Radiative'/'bin').mkdir(parents=True)
            (base/'API'/'examples'/'TMD_Maker.py').write_text('secret model contents')
            (base/'Radiative'/'bin'/'esatan-tms.exe').touch()
            (base/'licenses').mkdir();(base/'licenses'/'secret.lic').write_text('private-server')
            r=diagnostico.inspect_install(base,1)
            self.assertTrue(r['ejemplo_tmd_maker']);self.assertTrue(r['ejecutable_esatan'])
            self.assertEqual(r['versiones_en_nombre'],['2026'])
            self.assertNotIn(tmp,json.dumps(r));self.assertNotIn('private-server',json.dumps(r))

    def test_dry_diagnostic_does_not_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)/'out.json'
            with contextlib.redirect_stdout(io.StringIO()):diagnostico.main(['--dry-run','--output',str(dest)])
            self.assertFalse(dest.exists())

    def api(self, getter):
        lang=types.SimpleNamespace(TmdMaker=object)
        vis=types.SimpleNamespace(current_point_selection=getter)
        with patch('importlib.import_module',side_effect=lambda name:lang if name.endswith('lang') else vis):
            with contextlib.redirect_stdout(io.StringIO()):return prueba_workbench.run_probe()

    def test_read_only_probe(self):
        r=self.api(lambda:[('private-node',123,456)])
        self.assertEqual(r['lectura_workbench'],'OK')
        self.assertFalse(r['solver_probado']);self.assertNotIn('private-node',json.dumps(r))

    def test_signature_guard(self):
        def needs_arg(argument):raise AssertionError('Must not call')
        self.assertEqual(self.api(needs_arg)['lectura_workbench'],'FIRMA_LOCAL_NO_VERIFICABLE')

    def test_import_failure_is_not_connection_success(self):
        with patch('importlib.import_module',side_effect=ImportError('private-path')):
            with contextlib.redirect_stdout(io.StringIO()):r=prueba_workbench.run_probe()
        self.assertFalse(r['api_importable']);self.assertNotIn('private-path',json.dumps(r))

    def test_read_error_is_not_connection_success(self):
        def broken():raise RuntimeError('private-license-server')
        r=self.api(broken);self.assertEqual(r['lectura_workbench'],'ERROR')
        self.assertNotIn('private-license-server',json.dumps(r))

    def test_known_csv_extremes_and_limits(self):
        rows=postproceso_csv.read_rows(Path(__file__).parent/'ejemplo_ficticio.csv')
        summary=postproceso_csv.summarize(rows)
        self.assertEqual([(s['min'],s['max'],s['outside']) for s in summary],[(20,31,1),(15,23,1)])

    def test_bad_input(self):
        head='time_s,node_id,temperature_C,limit_min_C,limit_max_C\n'
        for content in ['0,a,nan,0,3\n','0,a,1,3,0\n','0,a,1,,\n0,a,2,,\n']:
            with tempfile.TemporaryDirectory() as tmp:
                f=Path(tmp)/'bad.csv';f.write_text(head+content)
                with self.assertRaises(ValueError):postproceso_csv.read_rows(f)

    def test_missing_limits_not_pass(self):
        r=postproceso_csv.summarize([{'node':'A','temp':3,'time':0,'low':None,'high':None}])
        self.assertEqual(r[0]['status'],'SIN LIMITES')

    def test_escape_html_and_csv(self):
        rows=[{'node':'<script>alert(1)</script>','temp':3,'time':0,'low':None,'high':None},
              {'node':'=1+1','temp':3,'time':0,'low':None,'high':None}]
        with tempfile.TemporaryDirectory() as tmp:
            postproceso_csv.write_report(postproceso_csv.summarize(rows),tmp,False)
            self.assertNotIn('<script>',(Path(tmp)/'informe.html').read_text())
            self.assertIn("'=1+1",(Path(tmp)/'resumen.csv').read_text(encoding='utf-8-sig'))


if __name__=='__main__':unittest.main()
