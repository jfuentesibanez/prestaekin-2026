"""Sonda de API ESATAN-TMS; ejecutar desde el contexto de plugin de Workbench.

No arranca el solver, no modifica ni guarda el modelo. La lectura opcional está
documentada para 2026 y solo se intenta si la firma local admite cero argumentos.
Ver README antes de ejecutar. No es un cliente HTTP.
"""
import importlib
import inspect
import json
import sys


def run_probe(read_selection=True):
    result = {'kit': 'Olma ESATAN 2026-11-25', 'api_importable': False,
              'lectura_workbench': 'NO_INTENTADA', 'solver_probado': False,
              'licencia_solver_validada': False,
              'python': '%s.%s.%s' % sys.version_info[:3]}
    try:
        lang = importlib.import_module('etms.lang')
        vis = importlib.import_module('etms.vis')
    except Exception as exc:
        result['estado'] = 'API_NO_IMPORTABLE_EN_ESTE_CONTEXTO'
        result['tipo_error'] = type(exc).__name__
        result['siguiente_paso'] = 'Usar el lanzador/contexto de plugins del API Guide instalado. Un Python externo puede no tener acceso a etms.'
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return result
    result['api_importable'] = True
    result['tmd_maker_disponible'] = hasattr(lang, 'TmdMaker')
    result['getter_seleccion_disponible'] = callable(getattr(vis, 'current_point_selection', None))
    result['estado'] = 'API_IMPORTABLE_LECTURA_PENDIENTE'
    if read_selection and result['getter_seleccion_disponible']:
        getter = vis.current_point_selection
        try:
            # No adivinar argumentos ni efectuar otra llamada al modelo.
            inspect.signature(getter).bind()
        except (TypeError, ValueError):
            result['lectura_workbench'] = 'FIRMA_LOCAL_NO_VERIFICABLE'
        else:
            try:
                selection = getter()
                result['lectura_workbench'] = 'OK'
                result['estado'] = 'LECTURA_API_OK_SOLVER_NO_PROBADO'
                # No mostrar nombres, coordenadas ni contenido del modelo.
                if isinstance(selection, (list, tuple, set, dict)):
                    result['numero_elementos_seleccionados'] = len(selection)
            except Exception as exc:
                result['lectura_workbench'] = 'ERROR'
                result['tipo_error_lectura'] = type(exc).__name__
    elif read_selection:
        result['lectura_workbench'] = 'GETTER_2026_NO_DISPONIBLE'
    result['nota'] = 'Importación y lectura no prueban cálculo térmico, licencia del solver ni equivalencia de resultados. Ningún dato de selección se incluye.'
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == '__main__':
    run_probe()
