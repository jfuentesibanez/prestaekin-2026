@echo off
setlocal
cd /d "%~dp0"
py -3.12 --version >nul 2>&1
if not errorlevel 1 (
  py -3.12 diagnostico.py --output resultados\diagnostico.json
  py -3.12 postproceso_csv.py --example --out resultados\ejemplo
  goto :fin
)
py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 diagnostico.py --output resultados\diagnostico.json
  py -3 postproceso_csv.py --example --out resultados\ejemplo
  goto :fin
)
python --version >nul 2>&1
if not errorlevel 1 (
  python diagnostico.py --output resultados\diagnostico.json
  python postproceso_csv.py --example --out resultados\ejemplo
  goto :fin
)
echo No se ha encontrado Python. Abre README.html y demo\informe.html.
echo No se ha instalado ni cambiado nada. Para API ESATAN 2026 consulta Python 3.12.x.
:fin
echo.
echo Este paso NO prueba la API, el solver ni la licencia de ESATAN.
echo Para la sonda real dentro de Workbench, lee README.html.
pause
