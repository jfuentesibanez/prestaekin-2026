# Olma · Prueba local de ESATAN y postproceso

Preparado para la tutoría del 25/11/2026. El kit usa solo la biblioteca estándar de Python. No instala paquetes, no modifica ESATAN, no busca un puerto HTTP y no envía datos a Internet.

## Lo que podéis probar mañana

1. **Sin ESATAN ni Python:** abrir `demo/informe.html`. Son seis muestras ficticias para ver un informe con gráfico, temperaturas extremas y límites. No prueba ninguna conexión.
2. **Con Python:** hacer inventario de instalación y procesar un CSV exportado. El diagnóstico no ejecuta ESATAN. El postproceso funciona por archivos y no requiere su API.
3. **Dentro de Workbench y con su API configurada:** ejecutar `prueba_workbench.py` en el contexto de plugins descrito por el API Guide de esa instalación. Separa importación de módulos de una llamada de lectura. No arranca ni valida el solver.

## 1. Inventario: 2 minutos

En Windows, descomprimir el ZIP en una carpeta de trabajo y abrir `INICIAR_WINDOWS.bat`. Genera `resultados/diagnostico.json` y un informe de ejemplo. No cambia variables de entorno ni configura la licencia.

Desde terminal, para indicar la instalación manualmente:

```text
py -3.12 diagnostico.py --install "C:\ESATAN-TMS\2026" --output "resultados\diagnostico.json"
```

En Linux:

```text
python3 diagnostico.py --install /opt/ESATAN-TMS/2026 --output resultados/diagnostico.json
```

`--dry-run` solo explica lo que haría, sin explorar ni escribir. No usar como `--install` una carpeta de clientes o modelos. El programa comprueba nombres de carpetas y presencia de componentes, sin leer modelos o licencias. No recoge rutas absolutas, usuario ni servidor de licencia en el informe. No encontrar una instalación no demuestra que no exista: indicad la ruta de su acceso directo.

**Versión:** las notas oficiales de ESATAN-TMS 2026 piden Python **3.12.x**, con 3.12.4 o posterior de esa rama recomendado para la API. El kit externo requiere Python 3.8 o superior; eso no hace compatible cualquier Python con ESATAN. Para otra versión, usar sus notas correspondientes. No actualizar ni desinstalar Python durante la tutoría sin revisar las dependencias del portátil.

`ESATAN_TMS_HOME` apunta a preferencias/modelos, no necesariamente a la instalación. El diagnóstico solo informa si está definida; no muestra su valor.

## 2. Prueba real de la API de Workbench: 5-10 minutos

Con Nacho, abrir ESATAN de la forma habitual y comprobar versión en su información de producto. Abrir el API Guide y un ejemplo sencillo instalado. La ubicación exacta y el mecanismo de registro/entrada del plugin dependen de esa versión; el kit no inventa menús ni un manifiesto.

1. Usar un **modelo de demostración o una copia prescindible**, abierto con su procedimiento habitual. No abrir un modelo de cliente para esta prueba.
2. Localizar el directorio `API` de la instalación y su guía. En 2026, el fabricante sitúa ejemplos en `API\examples`; entre ellos documenta `TMD_Maker`.
3. Siguiendo la guía local, ejecutar `prueba_workbench.py` desde el contexto de plugins. Si el ejemplo de la instalación requiere una función de entrada específica, conservar esa función y llamar a `run_probe()` desde ella. No ejecutar un `pip install etms` de un paquete desconocido.
4. La sonda importa los módulos documentados `etms.lang` y `etms.vis`. Para 2026 busca `current_point_selection`, comprueba que la firma local admite cero argumentos y solo entonces realiza esa lectura. No muestra nombres ni coordenadas; únicamente cuenta elementos si el resultado es una colección.
5. Para probar solo importación, invocar `run_probe(read_selection=False)`. Una API importable no demuestra conexión operativa con Workbench.

Resultados posibles:

| Resultado | Qué demuestra | Siguiente paso |
|---|---|---|
| `API_NO_IMPORTABLE_EN_ESTE_CONTEXTO` | Este intérprete no puede importar la API. | Revisar Python y el contexto de plugin del API Guide. No significa que ESATAN no esté instalado. |
| `API_IMPORTABLE_LECTURA_PENDIENTE` | Los módulos están accesibles. | Revisar el campo `lectura_workbench` y la documentación local. |
| `GETTER_2026_NO_DISPONIBLE` | No está el getter de 2026. | Usar el ejemplo read-only de la versión instalada. No adivinar otra llamada. |
| `FIRMA_LOCAL_NO_VERIFICABLE` | La firma no pudo validarse o requiere argumentos. | Consultar la firma en la guía local antes de adaptar el código. No se hizo la llamada. |
| `LECTURA_API_OK_SOLVER_NO_PROBADO` | Importación y llamada de lectura respondieron. | Ya se puede diseñar una automatización pequeña; sigue pendiente validar cálculo y licencia del solver. |

La sonda no ejecuta `run_analysis`, no guarda el modelo ni modifica atributos. El propio software puede comprobar su licencia al iniciarse o usar la API; el kit no altera el gestor de licencias. Un error solo registra el tipo de excepción para no copiar información del modelo o del servidor.

**Límite de la validación actual:** pruebas sintácticas y con módulos simulados realizadas aquí. No se ha probado una instalación real de ESATAN; esa comprobación depende del portátil que traiga Olma.

## 3. Primer caso útil: informe de temperaturas por CSV

```text
py -3.12 postproceso_csv.py --example --out resultados\ejemplo
py -3.12 postproceso_csv.py resultados_exportados.csv --out resultados\caso
```

Usar `python3` en Linux. `--dry-run` valida y calcula sin escribir archivos. El archivo debe ser CSV UTF-8 con **coma como separador y punto decimal**, en formato largo:

```csv
time_s,node_id,temperature_C,limit_min_C,limit_max_C
0,NODO_A,20,10,30
60,NODO_A,26,10,30
```

Las tres primeras columnas son obligatorias; los límites son opcionales. Debe haber una fila por nodo/instante. Si una exportación viene en formato ancho, otra unidad o cabeceras distintas, normalizar **una copia** primero y comprobar la transformación con Nacho. No basta con renombrar Kelvin como Celsius: convertir K a °C restando 273,15. Esta versión no promete aceptar directamente todos los formatos de exportación de ESATAN.

El programa rechaza muestras duplicadas, valores no finitos y límites invertidos. Genera:

- `informe.html`: resumen y gráfico imprimible a PDF; funciona sin Internet.
- `resumen.csv`: mínimos, máximos, número de muestras evaluadas y fuera de límite.
- `temperaturas.svg`: gráfico exportable.

Los extremos se calculan sobre las muestras proporcionadas, sin interpolar extremos físicos. Los límites proceden del CSV; si faltan, no se da la evaluación por aprobada. Las líneas del gráfico solo facilitan la lectura. Máximo 100.000 muestras; el gráfico muestra hasta 20 nodos y el resumen los incluye todos.

El fabricante documenta exportación de series de gráficos a CSV en las notas de 2019. Confirmad la opción equivalente en su versión y revisad unidades y cabeceras. Para 2026 también hay un ejemplo oficial `TMD_Maker` para crear TMD a partir de temperaturas CSV; es una alternativa posterior, no usada automáticamente por este kit.

## Prueba de valor durante la tutoría

Elegir un resultado ya revisado, generar el informe manual y con el script, comparar mínimos/máximos, unidades y límites, y medir el tiempo de preparación. Nacho valida la equivalencia. Decidir un siguiente automatismo solo si esta prueba resulta útil.

## Fuentes primarias consultadas el 24/11/2026

- [Centro de documentación ESATAN-TMS](https://www.esatan-tms.com/find/brochure.php).
- [Notas oficiales de instalación 2026](https://www.esatan-tms.com/find/downloadinstallfile.php?ID=c51ce410c124a10e0db5e4b97fc2af39), apartados de plataforma y Python: rama 3.12; Workbench API.
- [Notas oficiales de versión 2026](https://www.esatan-tms.com/find/downloadinstallfile.php?ID=c20ad4d76fe97759aa27a0c99bff6710), p. 10: `etms.vis.current_point_selection`, `etms.lang.TmdMaker`, ejemplo `API\examples`.
- [Notas oficiales de versión 2019 SP1](https://www.esatan-tms.com/images/release/1379151851_ESATAN-TMS2019_ReleaseNotes_April2019.pdf), p. 14: exportación de series a CSV.
- [Trabajo IDR/UPM presentado en ESA/ESTEC, 2024](https://indico.esa.int/event/520/contributions/9881/), referencia de automatización de modelos y postproceso, no un componente instalado por este kit.

Código de prueba preparado para Olma. Los documentos del fabricante se enlazan; no se redistribuyen. ESATAN-TMS y su licencia pertenecen a sus titulares.
