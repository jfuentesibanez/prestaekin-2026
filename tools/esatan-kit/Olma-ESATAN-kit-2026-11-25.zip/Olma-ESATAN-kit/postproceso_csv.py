#!/usr/bin/env python3
"""Postproceso local de un CSV normalizado. No usa ESATAN ni su solver."""
import argparse
import csv
import html
import math
from pathlib import Path


def finite(value, label):
    try:
        n = float(value)
    except (ValueError, TypeError):
        raise ValueError('%s: número inválido; usar punto decimal.' % label)
    if not math.isfinite(n):
        raise ValueError('%s: no se permite NaN o infinito.' % label)
    return n


def read_rows(path):
    rows, seen = [], set()
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        if not {'time_s', 'node_id', 'temperature_C'}.issubset(reader.fieldnames or []):
            raise ValueError('Cabeceras requeridas: time_s,node_id,temperature_C. Temperaturas en Celsius, tiempo en segundos.')
        for number, raw in enumerate(reader, 2):
            if number > 100001:
                raise ValueError('Máximo 100.000 muestras para esta prueba.')
            node = (raw.get('node_id') or '').strip()
            if not node or len(node) > 100:
                raise ValueError('Fila %d: node_id vacío o demasiado largo.' % number)
            time = finite(raw.get('time_s'), 'Fila %d / tiempo' % number)
            temp = finite(raw.get('temperature_C'), 'Fila %d / temperatura' % number)
            if time < 0:
                raise ValueError('Fila %d: tiempo negativo.' % number)
            if (node, time) in seen:
                raise ValueError('Fila %d: muestra duplicada para el mismo nodo/tiempo.' % number)
            seen.add((node, time))
            low = (raw.get('limit_min_C') or '').strip()
            high = (raw.get('limit_max_C') or '').strip()
            low = finite(low, 'límite inferior') if low else None
            high = finite(high, 'límite superior') if high else None
            if low is not None and high is not None and low > high:
                raise ValueError('Fila %d: límites invertidos.' % number)
            rows.append({'time': time, 'node': node, 'temp': temp, 'low': low, 'high': high})
    if not rows:
        raise ValueError('El CSV no contiene muestras.')
    return rows


def summarize(rows):
    groups = {}
    for row in rows:
        groups.setdefault(row['node'], []).append(row)
    out = []
    for node in sorted(groups):
        samples = sorted(groups[node], key=lambda r: r['time'])
        evaluated = [r for r in samples if r['low'] is not None or r['high'] is not None]
        outside = [r for r in evaluated if (r['low'] is not None and r['temp'] < r['low']) or
                   (r['high'] is not None and r['temp'] > r['high'])]
        out.append({'node': node, 'min': min(r['temp'] for r in samples),
                    'max': max(r['temp'] for r in samples), 'samples': len(samples),
                    'evaluated': len(evaluated), 'outside': len(outside),
                    'status': ('SIN LIMITES' if not evaluated else
                               'FUERA DE LIMITE' if outside else
                               'PARCIAL: SIN EXCESOS EN MUESTRAS EVALUADAS' if len(evaluated) < len(samples) else
                               'SIN EXCESOS EN MUESTRAS'), 'series': samples})
    return out


def chart(summary):
    colors = ['#c41230', '#007a78', '#1e60aa', '#9b4d00', '#682aa1']
    allrows = [r for s in summary for r in s['series']]
    t0, t1 = min(r['time'] for r in allrows), max(r['time'] for r in allrows)
    y0, y1 = min(r['temp'] for r in allrows), max(r['temp'] for r in allrows)
    pad = max(1, (y1-y0)*.1);y0 -= pad;y1 += pad
    tspan = max(t1-t0, 1)
    def x(t):return 70+(t-t0)/tspan*750
    def y(t):return 325-(t-y0)/(y1-y0)*270
    svg = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 410" role="img" aria-label="Temperaturas de las muestras por nodo">',
           '<rect width="900" height="410" fill="white"/>',
           '<path d="M70 45V325H830" fill="none" stroke="#777"/>']
    for i in range(6):
        value=y0+(y1-y0)*i/5
        svg.append('<path d="M70 %.2fH830" stroke="#eee"/><text x="60" y="%.2f" text-anchor="end" font-size="13">%.1f</text>'%(y(value),y(value)+5,value))
    for i,s in enumerate(summary[:20]):
        c=colors[i%len(colors)];pts=' '.join('%.2f,%.2f'%(x(r['time']),y(r['temp'])) for r in s['series'])
        svg.append('<polyline points="%s" fill="none" stroke="%s" stroke-width="2"/>'%(pts,c))
        for r in s['series'][:300]:
            svg.append('<circle cx="%.2f" cy="%.2f" r="3" fill="%s"><title>%s / %.2f s / %.2f C</title></circle>'%(x(r['time']),y(r['temp']),c,html.escape(s['node']),r['time'],r['temp']))
    svg.extend(['<text x="20" y="30" font-size="15">°C</text>',
                '<text x="70" y="350" font-size="13">%.2f s</text>'%t0,
                '<text x="820" y="350" text-anchor="end" font-size="13">%.2f s</text>'%t1,
                '<text x="440" y="385" text-anchor="middle" font-size="15">Tiempo (s)</text>','</svg>'])
    legends=' '.join('<span style="color:%s">■ %s</span>'%(colors[i%len(colors)],html.escape(s['node'])) for i,s in enumerate(summary[:20]))
    return ''.join(svg),legends


def csv_safe(value):
    value=str(value)
    return "'"+value if value.startswith(('=','+','-','@','\t','\r')) else value


def write_report(summary, out, example):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    svg,legend=chart(summary)
    (out/'temperaturas.svg').write_text(svg,encoding='utf-8')
    with (out/'resumen.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['nodo','min_C','max_C','muestras','evaluadas','fuera_limite','estado'])
        for s in summary:w.writerow([csv_safe(s['node']),s['min'],s['max'],s['samples'],s['evaluated'],s['outside'],s['status']])
    body=''.join('<tr><td>%s</td><td>%.2f</td><td>%.2f</td><td>%d</td><td>%d</td><td>%d</td><td>%s</td></tr>'%(html.escape(s['node']),s['min'],s['max'],s['samples'],s['evaluated'],s['outside'],s['status']) for s in summary)
    flag='EJEMPLO FICTICIO: no son resultados de Olma ni de ESATAN.' if example else 'Datos aportados por el usuario. Validar unidades, exportación y límites con Nacho.'
    document='''<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Olma · Prueba de postproceso</title><style>body{font:16px/1.55 system-ui,sans-serif;color:#20252a;max-width:1050px;margin:40px auto;padding:0 24px}h1{line-height:1.2}aside{padding:16px;border-left:5px solid #c41230;background:#fff1f3}svg{width:100%;height:auto}table{border-collapse:collapse;width:100%;margin:24px 0}td,th{padding:10px;text-align:left;border-bottom:1px solid #ddd}th{background:#edf0f3}small{font-size:14px}button{font:inherit;padding:10px 18px;background:#c41230;color:white;border:0;border-radius:6px}.scroll{overflow:auto}.legend span{margin-right:15px}@media print{button{display:none}body{margin:0;font-size:12px}table{font-size:10px}}</style><h1>Postproceso de temperaturas</h1><aside>'''+flag+'''<br>Este informe no ejecuta ni comprueba conexión con ESATAN, su API o su licencia.</aside><p>Resumen por nodo y comprobación de límites de las muestras del CSV. No certifica el comportamiento entre muestras ni la aceptación del diseño.</p><div class="legend">'''+legend+'''</div>'''+svg+'''<p><small>Gráfico: hasta 20 nodos; el resumen incluye todos. Líneas entre muestras para facilitar la lectura. Las unidades de entrada deben ser Celsius y segundos.</small></p><div class="scroll"><table><thead><tr><th>Nodo</th><th>Mín. °C</th><th>Máx. °C</th><th>Muestras</th><th>Evaluadas</th><th>Fuera</th><th>Resultado</th></tr></thead><tbody>'''+body+'''</tbody></table></div><p><a href="resumen.csv">Descargar resumen CSV</a> · <a href="temperaturas.svg">Abrir gráfico SVG</a></p><button onclick="window.print()">Imprimir / guardar PDF</button><p><small>Procesado localmente con el kit Olma. Sin cargas a servidores ni dependencias externas.</small></p></html>'''
    (out/'informe.html').write_text(document,encoding='utf-8')


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('csv',nargs='?',type=Path)
    p.add_argument('--example',action='store_true',help='Usa las seis muestras ficticias incluidas.')
    p.add_argument('--out',type=Path,default=Path('resultados-csv'))
    p.add_argument('--dry-run',action='store_true',help='Valida y calcula sin escribir archivos.')
    a=p.parse_args(argv)
    if bool(a.csv) == bool(a.example):p.error('Elegir un archivo CSV o --example, no ambos.')
    path=Path(__file__).parent/'ejemplo_ficticio.csv' if a.example else a.csv
    try:
        rows=read_rows(path);summary=summarize(rows)
    except (ValueError,OSError,csv.Error) as exc:
        p.exit(2,'No se ha generado informe: %s\n'%exc)
    if not a.dry_run:write_report(summary,a.out,a.example)
    print('CSV validado: %d muestras / %d nodos. %s'%(len(rows),len(summary),'Sin archivos escritos.' if a.dry_run else 'Informe HTML, SVG y CSV generados.'))
    print('No se ha probado conexión con ESATAN.')
    return 0


if __name__=='__main__':raise SystemExit(main())
